"""
Aggregate all views exposed by the certificates app.
"""
from lms.djangoapps.certificates.views.support import *
from lms.djangoapps.certificates.views.webview import *
from lms.djangoapps.certificates.views.xqueue import *
