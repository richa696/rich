# Make sure wiki_plugin.py gets run.  # lint-amnesty, pylint: disable=missing-module-docstring


from lms.djangoapps.course_wiki.plugins.markdownedx.wiki_plugin import ExtendMarkdownPlugin
