"""
Exceptions for the verify student app
"""


class WindowExpiredException(Exception):
    pass
