"""
Course API Blocks
"""
