Status: Active Development

Responsibilities
================
The courseware djangoapp is responsible for presenting course content to learners.

Glossary
========

More Documentation
==================
`Architectural Decision Records
<https://github.com/edx/edx-platform/tree/master/lms/djangoapps/courseware/docs/decisions>`_
