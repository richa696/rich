"""
A class which never gets imported except for in
:meth:`~courseware.tests.test_field_overrides.ResolveDottedTests.test_import_something_that_isnt_already_loaded`.
"""
SOMENAME = 'bar'
