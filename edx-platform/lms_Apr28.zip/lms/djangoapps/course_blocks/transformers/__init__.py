"""
Module container for all Course Block Access Transformers.
"""
