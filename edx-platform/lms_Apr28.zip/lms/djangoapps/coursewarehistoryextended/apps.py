# lint-amnesty, pylint: disable=missing-module-docstring
from django.apps import AppConfig


class CoursewareHistoryExtendedConfig(AppConfig):
    name = u'lms.djangoapps.coursewarehistoryextended'
