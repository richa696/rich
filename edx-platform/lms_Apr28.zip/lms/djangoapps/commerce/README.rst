Status: Maintenance

Responsibilities
================
The Commerce app is an older implementation of e-commerce related functionality.

Direction: Deprecate
====================
This app is replaced by functionality in the `ecommerce service`_. New functionality should not be added here. Effort is needed to determine who the existing clients are so they can be updated and this app can be removed. This app is in a similar situation to the ```lms/djangoapps/shoppingcart``` app.

.. _ecommerce service: https://github.com/edx/ecommerce

Glossary
========

More Documentation
==================
