# This file is intentionally blank. It has been moved to openedx/core/djangoapps/django_comment_common
