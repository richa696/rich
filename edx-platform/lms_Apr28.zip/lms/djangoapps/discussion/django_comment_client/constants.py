"""
Constants for Discussions
"""

TYPE_ENTRY = 'entry'  # A leaf node in a category hierarchy.
TYPE_SUBCATEGORY = 'subcategory'  # A non-leaf node in a category hierarchy.
