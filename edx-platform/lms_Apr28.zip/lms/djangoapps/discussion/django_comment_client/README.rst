See ``lms/djangoapps/discussion/README.rst``
